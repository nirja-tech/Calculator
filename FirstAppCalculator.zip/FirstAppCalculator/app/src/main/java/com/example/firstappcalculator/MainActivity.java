package com.example.firstappcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

 EditText ed1;
 Button btnClear;
 boolean isNewop=true;
 String op = "";
 String  Ores1="";


 boolean Add,Sub,Mul,Div;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed1=(EditText)findViewById(R.id.Result);
        btnClear=(Button)findViewById(R.id.Clear);


        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(" ");
            }
        });

    }


    public void numberEvent(View view)
    {

        if(isNewop)
            ed1.setText("");
        isNewop=false;
        String number=ed1.getText().toString();
    switch(view.getId())
    {

        case R.id.button1:
        number +="1";
        break;
        case R.id.button2:
            number +="2";
            break;
        case R.id.button3:
            number +="3";
            break;
        case R.id.button4:
            number +="4";
            break;
        case R.id.button5:
            number +="5";
            break;
        case R.id.button6:
            number +="6";
            break;
        case R.id.button7:
            number +="7";
            break;
        case R.id.button8:
            number +="8";
            break;
        case R.id.button9:
            number +="9";
            break;
        case R.id.button0:
            number +="0";
            break;
        case R.id.Dot:
            number +=".";
            break;
    }
    ed1.setText(number);
    }

    public void operatorEvent(View view) {
isNewop=true;
Ores1=ed1.getText().toString();
switch (view.getId())
{
    case R.id.Add:op="+"; break;
    case R.id.Sub:op="-"; break;
    case R.id.Divide:op="/"; break;
    case R.id.multiply:op="*"; break;
}
    }

    public void equalEvent(View view) {
        String newNumber = ed1.getText().toString();
        double result = 0.0;
        switch (op)
        {
            case "+":
                result=Double.parseDouble(Ores1)+Double.parseDouble(newNumber);
                break;
            case "-":
                result=Double.parseDouble(Ores1)-Double.parseDouble(newNumber);
                break;
            case "*":
                result=Double.parseDouble(Ores1)*Double.parseDouble(newNumber);
                break;
            case "/":
                result=Double.parseDouble(Ores1)/Double.parseDouble(newNumber);
                break;
        }
        ed1.setText(result+"");
    }
}